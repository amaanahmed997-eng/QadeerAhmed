# DevOps Lab 3 — GitHub Actions CI Demo

This project is created for your DevOps Lab 3 assignment. It automatically runs a Node.js test using GitHub Actions whenever you create a Pull Request.

## Steps to Use (Very Simple)
1. Create a new repository on GitHub (any name).
2. Upload this ZIP file, then click "Unzip" in GitHub or use "Add file" → "Upload files".
3. After upload, select the option **Create a new branch for this commit** and name it `ci-workflow`.
4. GitHub will automatically open a **Pull Request** window. Just click **Create pull request**.
5. Go to the **Actions** tab — you’ll see it start running automatically.
6. Wait 1–2 minutes. You’ll see green checkmarks and “PASS” for the test result.
7. Take screenshots of:
   - The Pull Request page showing the workflow run.
   - The Actions log showing tests passed.

That’s it — your lab is done!

## What the code does
- `index.js`: a simple add function.
- `index.test.js`: a Jest test to check the add function.
- `.github/workflows/ci.yml`: a GitHub Actions workflow that runs the tests automatically.
